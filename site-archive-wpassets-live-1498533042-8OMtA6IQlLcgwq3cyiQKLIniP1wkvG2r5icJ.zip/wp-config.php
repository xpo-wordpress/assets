<?php
# Database Configuration
define( 'DB_NAME', 'wp_wpassets' );
define( 'DB_USER', 'wpassets' );
define( 'DB_PASSWORD', 'qVimL6R3sNVLYKEjUmU5' );
define( 'DB_HOST', '127.0.0.1' );
define( 'DB_HOST_SLAVE', '127.0.0.1' );
define('DB_CHARSET', 'utf8');
define('DB_COLLATE', 'utf8_unicode_ci');
$table_prefix = 'wp_';

# Security Salts, Keys, Etc
define('AUTH_KEY',         'i#:![[y=6&E]gg^!]GU~A?XT]u8|%&GmQjXC@%DD+L9-E?XSka,- +]X&|P2U/*w');
define('SECURE_AUTH_KEY',  '4{B_FIBha]4bxv5s|^^]_n4%|!9(G^G4qC8cf|m9AgvHrzN]k17K>Op)bM1;pE+|');
define('LOGGED_IN_KEY',    ':4VC;3NEdsOZ[Jif092u;PP tLVn&9}<M?Z}R>MKaI9qreB  C9m|s%y3O-r)B]G');
define('NONCE_KEY',        'U2n3+Ew(-sYXK6+z,5K`Y4Z xHu~T-<BECL7{!7c+9wbvF_[foKVW.7!#T-/Dz8R');
define('AUTH_SALT',        '&088|)rZF5^b`~elcolSB)|aCLs6P5n+0(`<xvexe&r,|W*lk$t4cc+R{k%W787Z');
define('SECURE_AUTH_SALT', '.e66Cij|[.G&*;T$mF7FkTi]($e=*QG1{-b6_)dLnWuIa#+QT[vGiuQ|9kaK=K|#');
define('LOGGED_IN_SALT',   'vWt<AOfC1;z1kzI?O/!uLUD8gzA8a8Q)ajNvYJ`GrXk_P+ue85e;pyK>8zDH+%|d');
define('NONCE_SALT',       '*dkp2WZ9XwRyx2  cs|OFE|Z8#6dgLc9h&Y3,k&bK;yS=5o|$iONoj&xZt2pKT;$');


# Localized Language Stuff

define( 'WP_CACHE', TRUE );

define( 'WP_AUTO_UPDATE_CORE', false );

define( 'PWP_NAME', 'wpassets' );

define( 'FS_METHOD', 'direct' );

define( 'FS_CHMOD_DIR', 0775 );

define( 'FS_CHMOD_FILE', 0664 );

define( 'PWP_ROOT_DIR', '/nas/wp' );

define( 'WPE_APIKEY', 'ae73889b5cd44f278bf415a1ff762242851c742a' );

define( 'WPE_CLUSTER_ID', '110222' );

define( 'WPE_CLUSTER_TYPE', 'pod' );

define( 'WPE_ISP', true );

define( 'WPE_BPOD', false );

define( 'WPE_RO_FILESYSTEM', false );

define( 'WPE_LARGEFS_BUCKET', 'largefs.wpengine' );

define( 'WPE_SFTP_PORT', 2222 );

define( 'WPE_LBMASTER_IP', '' );

define( 'WPE_CDN_DISABLE_ALLOWED', true );

define( 'DISALLOW_FILE_MODS', FALSE );

define( 'DISALLOW_FILE_EDIT', FALSE );

define( 'DISABLE_WP_CRON', false );

define( 'WPE_FORCE_SSL_LOGIN', true );

define( 'FORCE_SSL_LOGIN', true );

/*SSLSTART*/ if ( isset($_SERVER['HTTP_X_WPE_SSL']) && $_SERVER['HTTP_X_WPE_SSL'] ) $_SERVER['HTTPS'] = 'on'; /*SSLEND*/

define( 'WPE_EXTERNAL_URL', false );

define( 'WP_POST_REVISIONS', FALSE );

define( 'WPE_WHITELABEL', 'wpengine' );

define( 'WP_TURN_OFF_ADMIN_BAR', false );

define( 'WPE_BETA_TESTER', false );

umask(0002);

$wpe_cdn_uris=array ( );

$wpe_no_cdn_uris=array ( );

$wpe_content_regexs=array ( );

$wpe_all_domains=array ( 0 => 'wpassets.wpengine.com', 1 => 'wpassets.xpo.com', );

$wpe_varnish_servers=array ( 0 => 'pod-110222', );

$wpe_special_ips=array ( 0 => '130.211.131.55', );

$wpe_ec_servers=array ( );

$wpe_largefs=array ( );

$wpe_netdna_domains=array ( );

$wpe_netdna_domains_secure=array ( );

$wpe_netdna_push_domains=array ( );

$wpe_domain_mappings=array ( );

$memcached_servers=array ( 'default' =>  array ( 0 => 'unix:///tmp/memcached.sock', ), );
define('WPLANG','');

# WP Engine ID


# WP Engine Settings






# That's It. Pencils down
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');
require_once(ABSPATH . 'wp-settings.php');

$_wpe_preamble_path = null; if(false){}
